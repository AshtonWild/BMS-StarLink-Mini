G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-11-04T16:52:44-07:00*
G04 #@! TF.ProjectId,BMS StarLink Mini,424d5320-5374-4617-924c-696e6b204d69,2026-11-03*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-11-04 16:52:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X-0.200000X-0.275000X0.200000X-0.275000X0.200000X0.275000X-0.200000X0.275000X0*%
%ADD11RoundRect,0.500000X-2.000000X-3.500000X2.000000X-3.500000X2.000000X3.500000X-2.000000X3.500000X0*%
%ADD12C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,TH1*
X76774999Y-47800000D03*
X78424999Y-47800000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,BT-1*
X4000000Y-69500000D03*
G04 #@! TD*
G04 #@! TO.C,BT-3*
X151000000Y-35500000D03*
G04 #@! TD*
G04 #@! TO.C,BT-4*
X74000000Y-35500000D03*
G04 #@! TD*
G04 #@! TO.C,BT-2*
X81500000Y-69500000D03*
G04 #@! TD*
G04 #@! TO.C,BT+2*
X151000000Y-69500000D03*
G04 #@! TD*
G04 #@! TO.C,BT+4*
X4000000Y-35500000D03*
G04 #@! TD*
G04 #@! TO.C,BT+1*
X73500000Y-69500000D03*
G04 #@! TD*
G04 #@! TO.C,BT+3*
X81500000Y-35500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H4*
X77500000Y-24000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,BT-5*
X36500000Y-10000000D03*
G04 #@! TD*
G04 #@! TO.C,BT+5*
X118500000Y-10000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H2*
X151000000Y-52500000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X4000000Y-52500000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X77500000Y-81000000D03*
G04 #@! TD*
M02*
